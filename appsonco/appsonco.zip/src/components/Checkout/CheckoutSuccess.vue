<template>
    <div class="alert alert-success text-center" role="alert">
        <h1>You are all set!</h1>
        Your purchase was successful.
    </div>
</template>

<script>
    import "@/css/home.css";

    export default{
        name: 'CheckoutSuccess'
    }
</script>

<style>
</style>