<template>
    <div class="alert alert-success text-center" role="alert">
        <h1>You are all set!</h1>
        Your quote request was sent.
    </div>
</template>

<script>
    import "@/css/home.css";

    export default{
        name: 'QuoteSuccess'
    }
</script>

<style>
</style>