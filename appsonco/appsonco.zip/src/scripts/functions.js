//import Vue from 'vue'

window.sendSearch = function() {
    console.log('Chama busca');
}




