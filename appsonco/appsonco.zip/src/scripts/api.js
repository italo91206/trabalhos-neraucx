//window.MagentoToken = 'rumrdgb9jhf1zc5fkvecxs2yt0x11pud'; // DEV ENV
window.MagentoToken = 'pa4confcboi8jvdjifzyqhfbj3bcjyr9'; // PRO ENV
window.MagentoApiUrl = 'https://www.soncocrowdcontrol.com/rest/V1/';
window.MagentoMediaUrl = 'https://www.soncocrowdcontrol.com/media/catalog/product/';
window.MagentoStoreId = '4';
